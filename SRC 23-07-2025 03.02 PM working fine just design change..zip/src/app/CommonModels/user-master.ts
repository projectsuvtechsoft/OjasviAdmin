export class UserMaster {
  ID: any = 0;
  ROLE_ID: any = 0;
  NAME: string = '';
  EMAIL_ID: string = '';
  MOBILE_NO: string = '';
  IS_ACTIVE: any
  STATUS: boolean = true;
  PASSWORD: string = '';
  CLOUD_ID: string = '';
  CLIENT_ID: number = 0;
  ORGANIZATION_ID: number = 0;
  MOBILE_NUMBER: any;
  ROLE_DATA: any = [];
  ROOM_NO: number;
  DESIGNATION_ID: any;
  PROFILE_PHOTO: any
  ORG_ID: any = 0;
  ORGANISATION_ID: any = 0;
}

