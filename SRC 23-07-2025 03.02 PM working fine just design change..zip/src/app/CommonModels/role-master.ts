export class RoleMaster {
  ID: number = 0;
  NAME: string = '';
  DESCRIPTION: string = '';
  TYPE: string = '';
  PARENT_ID: number = 0;
  CLIENT_ID: number = 0;
  IS_ACTIVE: boolean = true;
  PARENT_NAME: any;
}