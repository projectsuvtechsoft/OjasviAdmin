export class UnitMembershipSummary {

    ID:number=0;          
    UNIT_NAME:string=''; 
    GROUP_COUNT:number=0;             
    _20_21_MEMBER_COUNT:number=0;
    _21_22_MEMBER_COUNT:number=0; 
    CURRENT_TOTAL:number=0; 
}