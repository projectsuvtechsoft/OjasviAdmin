export class CartAddonMaster {
    ID:number=0;
    TITLE:string=''; 
    DESCRIPTION:string=''; 
    AMOUNT:number=0; 
    CART_TOTAL_PERCENTAGE :number=0 ;
    IS_AMOUNT_BASED :boolean = false
  
       
  }