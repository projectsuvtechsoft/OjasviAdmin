export class BlogMaster {
    ID:number=0;
    TITLE:string=''; 
    TITLE_MR:string=''; 
    DESCRIPTION:string=''; 
    DESCRIPTION_MR:string=''; 
    IMAGE:string='';    
    BLOGGER_NAME:string=''; 
    BLOGGER_NAME_MR:string=''; 
    SEQUENCE_NO:number=0; 
    STATUS:boolean=true; 
    BLOG_DATE:any=new Date();
}

