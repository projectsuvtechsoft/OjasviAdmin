
export class NewSubscriberReport {
    ID:number=0;    
    EMAIL_ID:string='';    
    DEVICE_ID:string='';
    DATE:any=new Date();   

}