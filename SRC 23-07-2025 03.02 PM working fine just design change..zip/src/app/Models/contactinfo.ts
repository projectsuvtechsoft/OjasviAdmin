export class ContactInfo {

    ID:number=0;  
    LONGITUDE  :string='';   
    LATITUDE:string='';   
    ADDRESS_DETAILS:string='';
    ADDRESS_DETAILS_MR:string='';
    EMAIL_ID:string='';
    CONTACT_NO:number=0;
    FB_LINK:string='';
    TW_LINK:string='';
    INSTA_LINK:string='';
    WHATSAPP_NO:number=0;
    SOCIAL_4_LINK:string='';
    SOCIAL_5_LINK:string='';
    STATUS:boolean=true;
    
    
}