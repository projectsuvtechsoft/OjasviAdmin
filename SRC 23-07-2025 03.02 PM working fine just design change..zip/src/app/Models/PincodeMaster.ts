export class PincodeMaster {

    ID:number=0;          
    PINCODE:any=0;    
    SHIPPING_CHARGES:number=0;          
    STATUS:boolean=true; 

}