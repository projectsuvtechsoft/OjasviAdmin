export class CategoryMaster {
    ID:number=0;
    CATEGORY_NAME:string=''; 
    CATEGORY_NAME_MR:string=''; 
    SEQUENCE_NO:number=0; 
    STATUS:boolean=true;
    SHORT_CODE:string='';  
    IMAGE:string='';    
}