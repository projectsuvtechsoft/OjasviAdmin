
export class UserContactReport {
    ID:number=0;    
    NAME:string=''; 
    MOBILE_NO:number=0;    
    EMAIL_ID:string=''; 
    SUBJECT:string=''; 
    MESSAGE:string='';  
}