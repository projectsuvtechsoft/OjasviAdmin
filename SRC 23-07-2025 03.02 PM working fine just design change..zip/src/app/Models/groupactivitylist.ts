export class GroupActivityList {

    ID:number=0;          
    UNIT_NAME:string='';          
    GROUP_NAME:string='';          
    ACTIVITY:string='';
    DATE:any; 
    
}