export class UserMaster {

    ID:number=0;
    ROLE_ID:number=0;
    NAME:string='';
    EMAIL_ID:string='';
    MOBILE_NO:string='';
    IS_ACTIVE:boolean=true;
    PASSWORD:string='';
    CLOUD_ID:string='';
    CLIENT_ID:number=0;
    ORGANIZATION_ID:number=0;
    
}