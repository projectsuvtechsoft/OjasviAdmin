export class StateMaster {

    ID:number=0;          
    NAME:string='';
    // COUNTRY_NAME:string='';
    STATUS:boolean=true; 
    SEQUENCE_NO:number=0 ;
    SHORT_CODE:string='';  
    COUNTRY_ID:number=0 ;

}