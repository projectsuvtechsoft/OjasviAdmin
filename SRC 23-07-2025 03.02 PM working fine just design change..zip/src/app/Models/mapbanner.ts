export class MapBanner {

    ID:number=0;          
    ADVERTIES_ID:number=0;  
    PRICING_TYPE:string='T';
    FROM_DATE=new Date()
    TO_DATE:any
    PER_DAY_RATE:number=0;  
    MAX_VIEW_COUNT:number=0;  
    PER_VIEW_RATE:number=0;  
    IS_UNIQUE:boolean=true;
    MAP_TYPE:any=[];
    STATUS:boolean=true;
    TOTAL_AMOUNT:number=0;  
    // CLIENT_ID:number=0;  
}