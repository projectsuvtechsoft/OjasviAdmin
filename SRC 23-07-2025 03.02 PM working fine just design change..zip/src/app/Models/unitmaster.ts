export class UnitMaster {

    ID:number=0;          
    UNIT_NAME:string='';
    UNIT_NAME_MR:string='';    
    STATUS:boolean=true; 
    SEQUENCE_NO:number=0 ;

}