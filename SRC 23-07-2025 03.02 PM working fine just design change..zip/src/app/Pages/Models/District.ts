export class DistrictMaster {
    ID: number;
    NAME: string = '';
    COUNTRY_ID: number;
    STATE_ID: number;
    SEQ_NO: number;
    IS_ACTIVE: boolean = true;
}