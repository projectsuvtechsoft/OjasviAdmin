export class UnitMasterData
{
  NAME=''
  SHORT_CODE=''
  SEQ_NO :number
  IS_ACTIVE:boolean=true
}
