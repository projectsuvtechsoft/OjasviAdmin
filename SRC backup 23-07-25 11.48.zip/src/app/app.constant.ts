export const url = {
  // link: 'https://pockit.pockitengineers.com/auth/', // Pre-production Server
  // link: 'https://20.197.51.80:7849/', // Preduction Server IP
  // link: 'https://pockitadmin.uvtechsoft.com:8767/', // Testing Server
  // link: 'https://1786vqrk-9898.inc1.devtunnels.ms/',// ngrok darshan
  // link: 'https://pn5m5nf6-8090.inc1.devtunnels.ms/', // ngrok ujef
  // link: 'https://m9fz3n36-8767.inc1.devtunnels.ms/',// ngrok Pranali
  link: 'https://2ab951c04a5f.ngrok-free.app/', // ngrok Bahubali
  // link: 'http://192.168.29.183:8767/',// ngrok darshan
};
export const appkeys = {
  gmUrl: 'http://gm.tecpool.in:8079/',
  socketUrl: 'http://pms.tecpool.in:3934',
  baseUrl: url.link,
  url: url.link + 'api/',
  imgUrl: url.link + 'api/upload/',
  imgUrl1: url.link + 'upload/',
  retriveimgUrl: url.link + 'static/',
};
