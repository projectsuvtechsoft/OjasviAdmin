export class AboutMaster {

    ID:number=0;    
    TITLE:string='';
    TITLE_MR:string='';
    IMG_URL:string='';    
    TEXT:string='';
    TEXT_MR:string='';
    STATUS:boolean=true;
    SEQUENCE_NO:number=0 ;
}