export class packagingcharges {

    ID:number=0;          
    WEIGHT:number=0 ;
    IN_COUNTRY:number=0 ;
    OUT_COUNTRY:number=0 ;
    STATUS:boolean=true; 




}