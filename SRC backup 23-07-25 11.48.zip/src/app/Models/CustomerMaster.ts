export class CustomerMaster {
    ID:number=0;
    NAME:string=''; 
    EMAIL_ID:string=''; 
    PASSWORD:string=''; 
    MOBILE_NO:any; 
    STATUS:boolean=true; 
    SEQUENCE_NO:number=0 ;
  
       
  }