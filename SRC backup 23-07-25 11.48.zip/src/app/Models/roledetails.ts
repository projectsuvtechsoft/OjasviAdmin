export class Roledetails {
    ID: number=0;
    ROLE_ID: number=0;
    FORM_ID:number=0;
    SEQ_NO:number=0;
    IS_ALLOWED:boolean=true;
    FORM_NAME:string='';
    PARENT_ID:number=0;
    PARENT_FORM_NAME:string='';
    LINK:string='';
    CLIENT_ID:number=0;
}