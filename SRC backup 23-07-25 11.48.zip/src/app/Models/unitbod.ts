export class UnitBOD {

    ID:number=0;          
    NAME:string='';          
    DIRECTOR:string='';
    OFFICER1:string='';
}