
export class AddressMaster {

    ID:number=0;          
    UNIT_NAME:string='';
    UNIT_NAME_MR:string='';    
    STATUS:boolean=true; 
    SEQUENCE_NO:number=0 ;
    IS_DEFUALT_ADDRESS:boolean=true;
    ADDRESS_TYPE:any='R';
    LANDMARK:string=''
    STATE_NAME:string=''
    STATE_ID:number=0;
    COUNTRY_ID:number=0;
    IS_LAST_SHIPPING_ADDRESS:boolean=false;

    CITY:string=''
    ADDRESS:string=''
    LOCALITY:string=''
    PINCODE:any=0
    MOBILE_NO:any;  
    NAME:string=''
    CUST_ID:number=0;  
  }