export class AdBannerMaster {

    ID:number=0;    
    NAME:string=''; 
    NAME_MR:string='';
    IMG_URL:string='';
    STATUS:boolean=true;
    SEQUENCE_NO:number=0;  
    SUB_TITLE:string='';
    SUB_TITLE_MR:string='';
    SUB_TITLE2:string='';
    SUB_TITLE2_MR:string='';
    COLOR_CODE_T1:any;
    COLOR_CODE_T2:any;
    COLOR_CODE_NAME:any;
}