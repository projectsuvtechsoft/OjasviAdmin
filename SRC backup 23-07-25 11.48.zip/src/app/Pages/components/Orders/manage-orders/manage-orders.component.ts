import { Component } from '@angular/core';
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-manage-orders',
  templateUrl: './manage-orders.component.html',
  styleUrls: ['./manage-orders.component.css'],
})
export class ManageOrdersComponent {
  statusCategories = [
    'Pending Orders',
    'Preparing',
    'Order Prepared',
    'Packaging',
    'Packaged',
    'Dispatching',
    'Dispatched',
    'Delivered',
  ];

  orders: { [key: string]: any[] } = {
    'Pending Orders': [],
    Preparing: [],
    'Order Prepared': [],
    Packaging: [],
    Packaged: [],
    Dispatching: [],
    Dispatched: [],
    Delivered: [],
  };

  ngOnInit(): void {
    // Dummy JSON loads – simulate different API calls
    this.orders['Pending Orders'] = [
      { id: 1, name: 'Order #1001', STATUS: 'Pending Orders' },
      { id: 2, name: 'Order #1002', STATUS: 'Pending Orders' },
    ];
    this.orders['Preparing'] = [
      { id: 3, name: 'Order #1003', STATUS: 'Preparing' },
    ];
    this.orders['Dispatched'] = [
      { id: 4, name: 'Order #1004', STATUS: 'Dispatched' },
    ];
    // Add more if needed
  }

  drop(event: CdkDragDrop<any[]>, newStatus: string): void {
    if (event.previousContainer === event.container) return;

    const movedOrder = event.previousContainer.data[event.previousIndex];

    // Update STATUS
    movedOrder.STATUS = newStatus;

    transferArrayItem(
      event.previousContainer.data,
      event.container.data,
      event.previousIndex,
      event.currentIndex
    );
  }
}
