export class StateMaster {
    ID: number;
    NAME: string = '';
    SHORT_CODE: any;
    COUNTRY_ID: number;
    SEQ_NO: number;
    IS_ACTIVE: boolean = true;
}