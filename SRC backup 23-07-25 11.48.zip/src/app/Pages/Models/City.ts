export class CityMaster {
    ID: number;
    NAME: string = '';
    COUNTRY_ID: number;
    DISTRICT_ID: any;
    CITY_ID;
    STATE: any;
    STATE_ID: any;
    DISTRICT: any;
    SEQ_NO: number;
    IS_ACTIVE: boolean = true;
}