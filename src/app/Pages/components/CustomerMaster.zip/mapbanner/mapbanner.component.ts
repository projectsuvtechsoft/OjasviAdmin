import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { DatePipe } from '@angular/common';
import { ApiServiceService } from 'src/app/Service/api-service.service';
// import { BannerMap } from 'src/app/Models/bannermap';
import { differenceInCalendarDays, setHours } from 'date-fns';
import { MapBanner } from 'src/app/Models/mapbanner';


@Component({
  selector: 'app-mapbanner',
  templateUrl: './mapbanner.component.html',
  styleUrls: ['./mapbanner.component.css']
})
export class MapbannerComponent implements OnInit {

  @Input()
  drawerClose!: Function;
  @Input()
  data: MapBanner = new MapBanner();
  @Input()
  drawerVisible: boolean = false;
  isSpinning = false;
  isOk = true;
  emailpattern = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  // namepatt=/^[a-zA-Z \-\']+/
  namepatt = /[a-zA-Z][a-zA-Z ]+/
  mobpattern = /^[6-9]\d{9}$/
  fileURL: any;
  today2 = new Date();


  @Input()
  data1: any;
  @Input()
  drawerClose1!: Function;
  @Input()
  mapdrawerVisible: boolean = false;
  PRICING_TYPE: any = 'T';
  FROM_DATE = new Date();
  TO_DATE = new Date();
  RATE: any;
  IS_UNIQUE: boolean = true;
  STATUS: boolean = true;
  AMOUNT: any;
  COUNT: any;
  MAPTYPE: any = []
  constructor(private api: ApiServiceService, private message: NzNotificationService,private datePipe: DatePipe) { }

  ngOnInit(): void {
  }
  disabledStartDate = (current: Date): boolean =>
    differenceInCalendarDays(current, this.today2) < 0;

  //// Only number
  omit(event: any) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  save(addNew: boolean, websitebannerPage: NgForm): void {


    console.log('Count::::', this.data.PRICING_TYPE);

    this.isSpinning = false;
    this.isOk = true;

    if (
      this.data.FROM_DATE == null &&
      this.data.TO_DATE == null &&
      this.data.PER_DAY_RATE == 0 &&
      this.data.MAP_TYPE.length == 0 &&
       this.data.TOTAL_AMOUNT == 0 &&
      this.data.FROM_DATE == null &&
      this.data.TO_DATE == null &&
      this.data.MAX_VIEW_COUNT == 0 &&
      this.data.PER_VIEW_RATE == 0 &&
      this.data.MAP_TYPE.length == 0 && 
      this.data.TOTAL_AMOUNT == 0

    ) {
      this.isOk = false;
      this.message.error(' Please Fill All Required Fields', '');
    } else
      if ((this.data.PRICING_TYPE == 'T' &&(this.data.FROM_DATE == null || this.data.FROM_DATE == undefined))
      ) {
        this.isOk = false;
        this.message.error('Please Select From Date', '');
      } else
      if ((this.data.PRICING_TYPE == 'T' &&(this.data.TO_DATE == null || this.data.TO_DATE == undefined))
      ) {
        this.isOk = false;
        this.message.error('Please Select To Date', '');

      } else
      if ((this.data.PRICING_TYPE == 'T' &&(this.data.PER_DAY_RATE == 0 || this.data.PER_DAY_RATE == null))
      ) {
        this.isOk = false;
        this.message.error('Please Enter Per Day Rate', '');


      } else
      if ((this.data.PRICING_TYPE == 'V' &&(this.data.FROM_DATE == null || this.data.FROM_DATE == undefined))
      ) {
        this.isOk = false;
        this.message.error('Please Select From Date', '');
      } else
      if ((this.data.PRICING_TYPE == 'V' &&(this.data.TO_DATE == null || this.data.TO_DATE == undefined))
      ) {
        this.isOk = false;
        this.message.error('Please Select To Date', '');

      } else
      if ((this.data.PRICING_TYPE == 'V' &&(this.data.MAX_VIEW_COUNT == 0 || this.data.MAX_VIEW_COUNT == null))
      ) {
        this.isOk = false;
        this.message.error('Please Enter Max View Count', '');
      } else
      if ((this.data.PRICING_TYPE == 'V' &&(this.data.PER_VIEW_RATE == 0 || this.data.PER_VIEW_RATE == null))
      ) {
        this.isOk = false;
        this.message.error('Please Enter Per View Rate', '');

      } else
      if (this.data.MAP_TYPE.length == 0 )
       {
        this.isOk = false;
        this.message.error('Please Select Map Types', '');

      } else
      if (this.data.TOTAL_AMOUNT == 0 || this.data.TOTAL_AMOUNT == null )
       {
        this.isOk = false;
        this.message.error('Please Enter Total Amount', '');
      } 
   
      if (this.isOk) {
        this.isSpinning = true;

    // if (this.data.ID) {
    //   this.api.updateProductMaster(this.data).subscribe((successCode) => {
    //     if (successCode.code == '200') {
    //       this.message.success(' Information Updated Successfully...', '');
    //       if (!addNew) this.drawerClose();
    //       this.isSpinning = false;
    //     } else {
    //       this.message.error(' Failed To Update Information...', '');
    //       this.isSpinning = false;
    //     }
    //   });
    // } else {
    //   this.api
    //     .createProductMaster(this.data)
    //     // this.type=.TYPE_ID
    //     .subscribe((successCode) => {
    //       if (successCode.code == '200') {
    //         this.message.success(' Information Save Successfully...', '');
    //         if (!addNew) this.drawerClose();
    //         else {
    //           // this.data = new ProductMaster();
    //           // this.resetDrawer(websitebannerPage);
    //           this.api.getAllProductMaster(1, 1, '', 'desc', '').subscribe(
    //             (data) => {
    //               // if (data['count']==0){
    //               //   this.data.SEQUENCE_NO=1;
    //               // }else
    //               // {
    //               //   this.data.SEQUENCE_NO=data['data'][0]['SEQUENCE_NO']+1;
    //               // }
    //             },
    //             (err) => {
    //               console.log(err);
    //             }
    //           );
    //         }
    //         this.isSpinning = false;
    //       } else {
    //         this.message.error(' Failed To Save Information...', '');
    //         this.isSpinning = false;
    //       }
    //     });
    // }

    // else
    // {
    //   this.message.error("Please Fill All Required Fields...","");
    //   this.isSpinning = false;

    }
  }
  close(): void {
    this.drawerClose();
  }

  perDayRate(event:any){
    
    if(this.data.FROM_DATE == null && this.data.TO_DATE == null){
      this.message.error('First Select From Date & To Date', '');
      // this.data.PER_DAY_RATE =0
    } else
    if(this.data.FROM_DATE != null && this.data.TO_DATE == null){
      this.message.error('Select To Date', '');
      // this.data.PER_DAY_RATE =0

    }else
    if(this.data.FROM_DATE == null && this.data.TO_DATE != null){
      this.message.error('Select From Date', '');
      // this.data.PER_DAY_RATE =0

    } else
    {
      // var value1:any = this.datePipe.transform(this.data.FROM_DATE, "yyyy-MM-dd")
      // console.log('value1',value1);

      // var value2:any = this.datePipe.transform(this.data.TO_DATE, "yyyy-MM-dd")
      // console.log('value2',value2);

      var Difference_In_Time = this.data.TO_DATE.getTime() - this.data.FROM_DATE.getTime();
      // console.log('Difference_In_Time',Difference_In_Time);
      
      // To calculate the no. of days between two dates
      var Difference_In_Days = Math.round(Difference_In_Time / (1000 * 3600 * 24));
      console.log('Difference_In_Days',Difference_In_Days);
      var a =Difference_In_Days * event
      this.data.TOTAL_AMOUNT = a
      
    }
    console.log(event);
    
  }

  priceType(event:any){
console.log(event,'ooo');

    if(event = "'T'" && this.data.TOTAL_AMOUNT > 0){
      this.data.TOTAL_AMOUNT = 0
    } else
    if(event = "'V'" && this.data.TOTAL_AMOUNT > 0){
      this.data.TOTAL_AMOUNT = 0
    }
  }

  // disableEndDate2(){
  //   if(this.data.FROM_DATE != null){
  //   return (current: Date): boolean =>
  //   differenceInCalendarDays(current,new Date( this.data.FROM_DATE)) < 0;
  //   }else{
  //     return (current: Date): boolean =>
  //     differenceInCalendarDays(current, this.today2) < 0;
  //   }
  // }
}
