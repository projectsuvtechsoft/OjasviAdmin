import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MapbannerComponent } from './mapbanner.component';

describe('MapbannerComponent', () => {
  let component: MapbannerComponent;
  let fixture: ComponentFixture<MapbannerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MapbannerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MapbannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
