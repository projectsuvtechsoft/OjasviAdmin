import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { OrderDetailMaster } from 'src/app/Models/orderdetail';
import { StateMaster } from 'src/app/Models/StateMaster';
import { ApiServiceService } from 'src/app/Service/api-service.service';
import { differenceInCalendarDays, setHours } from 'date-fns';
import { DatePipe } from '@angular/common';

import * as moment from 'moment';
// import { differenceInCalendarDays, setHours } from 'date-fns';
@Component({
  selector: 'app-add-order',
  templateUrl: './add-order.component.html',
  styleUrls: ['./add-order.component.css'],
})
export class AddOrderComponent implements OnInit {
  constructor(
    private message: NzNotificationService,
    private api: ApiServiceService,
    private datepipe: DatePipe
  ) {}


  loaddata:any
  @Input()
  OrdersID:any

  detailslist: any;
  ngOnInit(): void {
    console.log("orders"+this.OrdersID)
    this.loaddata = true
    this.api
      .getAllOrderMaster(0, 0, '', '', " AND CURRENT_STAGE = 'A' AND ID = "+this.OrdersID)
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.loaddata = false
            this.detailslist = JSON.parse(data['data'][0]['CART_ITEMS']);
            
          } else {
            this.loaddata = false
            // this.message.error('Something Went Wrong', '');
          }
        },
        (err) => {
          console.log(err);
        }
      );
  }
  startValue: any;
  endValue: any;
  endOpen = false;
  startOpen = false;

  dates: any = [];
  today2 = new Date();
  today =
    new Date().getFullYear().toString() +
    '-' +
    (new Date().getMonth() + 1).toString() +
    '-' +
    new Date().getDate().toString();
  current = new Date();
  month = this.today;

  disabledEndDate2 = (current: Date): any => {
    let index = this.dates.findIndex(
      (date: any) => date === moment(current).format('YYYY-MM-DD')
    );
    return index === -1 && true;
  };

  startDateChange() {
    var startDate = this.datepipe.transform(this.startValue, 'yyyy-MM-dd');
    var endDate = this.datepipe.transform(new Date(), 'yyyy-MM-dd');

    console.log(this.getDaysArray(startDate, endDate));
    console.log(this.dates);
  }

  getDaysArray(start: any, end: any) {
    for (
      var arr = [], dt = new Date(start);
      dt <= new Date(end);
      dt.setDate(dt.getDate() + 1)
    ) {
      arr.push(this.datepipe.transform(dt, 'yyyy-MM-dd'));
      this.dates.push(this.datepipe.transform(dt, 'yyyy-MM-dd'));
    }
    return arr;
  }

  timeDefaultValue = setHours(new Date(), 0);

  disabledStartDate2 = (current: Date): boolean =>
    differenceInCalendarDays(current, this.today2) < 0;

  disabledStartDate3 = (current: Date): boolean =>
    differenceInCalendarDays(current, this.data.EXPECTED_DISPATCH_DATETIME) < 0;


    // disabledStartDate4 = (current: Date): boolean =>
    // differenceInCalendarDays(current, this.data.EXPECTED_BEING_PREPARE) < 0;

  moduleStartDateHandle(open: boolean) {
    if (!open) {
      this.endOpen = true;
    }
  }


  // radioval='A';
  @Input()
  drawerClose!: Function;
  @Input()
  data: OrderDetailMaster = new OrderDetailMaster();
  @Input()
  drawerVisible: boolean = false;
  rejectremark: OrderDetailMaster[] = [];

 
  isSpinning = false;

  dateFormat = 'dd-MM-yyyy';

  todays = new Date();

  disabled = (current: Date): boolean =>
    differenceInCalendarDays(current, this.todays) < 0;

  filteredOptions: any[] = [];

  onChange(event: Event): void {
    console.log(event);
    this.filteredOptions = this.rejectremark.filter((option) => {
      return option['REJECT_REMARK'].includes(event.toString());
    });
  }


  close(): void {
    this.drawerClose();
  }



  isOk = true;

 
  loadingRecords1 = false;

  resetDrawer(websitebannerPage: NgForm) {
    this.data = new OrderDetailMaster();
    websitebannerPage.form.markAsPristine();
    websitebannerPage.form.markAsUntouched();
  }

  // update(addNew: boolean, websitebannerPage: NgForm) {
  //   if (
  //     this.data.ORDER_STATUS == 'A' &&
  //     (this.data.EXPECTED_DISPATCH_DATETIME == undefined ||
  //       this.data.EXPECTED_DISPATCH_DATETIME == null)
  //   ) {
  //     this.isOk = false;
  //     this.message.error('Please Select Expected Dispatch Date. ', '');
  //   } else if (
  //     this.data.ORDER_STATUS == 'A' &&
  //     (this.data.EXPECTED_DELIVERY_DATETIME == undefined ||
  //       this.data.EXPECTED_DELIVERY_DATETIME == null)
  //   ) {
  //     this.isOk = false;
  //     this.message.error('Please Select Expected Delivery Date. ', '');
  //   }

  //   if (this.isOk) {

  //     // this.roleId = Number(sessionStorage.getItem("userId"))
  //     // this.isSpinning=false;
  //     // this.data.ORDER_CONFIRMED_ID = Number(sessionStorage.getItem("userId"))
  //     // this.data.ORDER_CONFIRMED_DATETIME = this.datepipe.transform(new Date(), 'yyyy-MM-dd HH:mm:ss');

  //     this.data.EXPECTED_DELIVERY_DATETIME = this.datepipe.transform(
  //       new Date(this.data.EXPECTED_DELIVERY_DATETIME),
  //       'yyyy-MM-dd HH:mm:ss'
  //     );
  //     this.data.EXPECTED_DISPATCH_DATETIME = this.datepipe.transform(
  //       new Date(this.data.EXPECTED_DISPATCH_DATETIME),
  //       'yyyy-MM-dd HH:mm:ss'
  //     );

  //     console.log('order date time ', this.data.ORDER_CONFIRMED_DATETIME);

  //     this.isSpinning = true;
  //     if (this.data.ID) {
  //       this.api.updateOrderMaster(this.data).subscribe((successCode) => {
  //         if (successCode.code == '200') {
  //           this.message.success(' Information Updated Successfully...', '');
  //           if (!addNew) this.drawerClose();
  //           this.isSpinning = false;
  //         } else {
  //           this.message.error(' Failed To Update Information...', '');
  //           this.isSpinning = false;
  //         }
  //       });
  //     }
  //   }
  // }

  save(addNew: boolean, websitebannerPage: NgForm): void {
    this.isSpinning = false;
    this.isOk = true;

    // if (
    //   this.data.ORDER_STATUS == 'A' &&
    //   (this.data.EXPECTED_DISPATCH_DATETIME == undefined ||
    //     this.data.EXPECTED_DISPATCH_DATETIME == null)
    // ) {
    //   this.isOk = false;
    //   this.message.error('Please Select Expected Dispatch Date. ', '');
    // } else
  
    
    if (
      this.data.ORDER_STATUS == 'R' &&
      (this.data.REJECT_REMARK == undefined || this.data.REJECT_REMARK == null)
    ) {
      this.isOk = false;
      this.message.error(' Please Enter Remark ', '');
    }
   

    if (this.isOk) {
      this.data.USER_ID = Number(sessionStorage.getItem('userId'));

   
      
      this.data.FROM_STAGE = 'Order Confirmed';
      this.data.TO_STAGE = 'Reject';
      this.data.ORDER_STATUS = 'R'
      this.data.CURRENT_STAGE = 'N/A'

   
      // console.log('order date time ', this.data.ORDER_CONFIRMED_DATETIME);
      this.data.ORDER_CONFIRMED_DATETIME = this.datepipe.transform(
        new Date(),
        'yyyy-MM-dd HH:mm:ss'
      );
      this.isSpinning = true;
      // if (this.data.ID) {
      this.api.updateOrderMaster(this.data).subscribe((successCode) => {
        if (successCode.code == '200') {
          this.message.success(' Information Updated Successfully...', '');
          if (!addNew) this.drawerClose();
          this.isSpinning = false;
        } else {
          this.message.error(' Failed To Update Information...', '');
          this.isSpinning = false;
        }
      });

     
    }

   
  }

  
  Preparing(addNew: boolean, websitebannerPage: NgForm): void {
    this.isSpinning = false;
    this.isOk = true;

    if (
      (this.data.EXPECTED_BEING_PREPARE == undefined ||
        this.data.EXPECTED_BEING_PREPARE == null)
    ) {
      this.isOk = false;
      this.message.error('Please Select Expected Preparing Date. ', '');
    }
    else  if (
      (this.data.EXPECTED_DELIVERY_DATETIME == undefined ||
        this.data.EXPECTED_DELIVERY_DATETIME == null)
    ) {
      this.isOk = false;
      this.message.error('Please Select Expected Delivery Date. ', '');
    }

  
    if (this.isOk) {
      this.isSpinning = true;

      this.data.FROM_STAGE = 'Order Confirmed';
      this.data.TO_STAGE = 'Preparing';
      this.data.ORDER_STATUS = 'A'
      this.data.CURRENT_STAGE = 'BP'

      // this.data.ORDER_STATUS = 'A';
      this.data.USER_ID = Number(sessionStorage.getItem('userId'));

      this.data.EXPECTED_BEING_PREPARE = this.datepipe.transform(
        new Date(this.data.EXPECTED_BEING_PREPARE),
        'yyyy-MM-dd HH:mm:ss'
      );
      this.data.EXPECTED_DELIVERY_DATETIME = this.datepipe.transform(
        new Date(this.data.EXPECTED_DELIVERY_DATETIME),
        'yyyy-MM-dd HH:mm:ss'
      );

      this.data.ORDER_CONFIRMED_DATETIME = this.datepipe.transform(
        new Date(),
        'yyyy-MM-dd HH:mm:ss'
      );

      // if (this.data.ID) {
      this.api.updateOrderMaster(this.data).subscribe((successCode) => {
        if (successCode.code == '200') {
          this.message.success(' Information Updated Successfully...', '');
          if (!addNew) this.drawerClose();
          this.isSpinning = false;
        } else {
          this.message.error(' Failed To Update Information...', '');
          this.isSpinning = false;
        }
      });

      // }
    }

   
  }

  packaging(addNew: boolean, websitebannerPage: NgForm): void {
    this.isSpinning = false;
    this.isOk = true;

    if (
     
      (this.data.EXPECTED_PREPARE_PACKAGING_DATETIME == undefined ||
        this.data.EXPECTED_PREPARE_PACKAGING_DATETIME == null)
    ) {
      this.isOk = false;
      this.message.error('Please Select Expected Prepare Packaging Date. ', '');
    }
    else  if (
      (this.data.EXPECTED_DELIVERY_DATETIME == undefined ||
        this.data.EXPECTED_DELIVERY_DATETIME == null)
    ) {
      this.isOk = false;
      this.message.error('Please Select Expected Delivery Date. ', '');
    }

    if (this.isOk) {
      this.isSpinning = true;

      this.data.FROM_STAGE = 'Order Confirmed';
      this.data.TO_STAGE = 'Packaging';
      this.data.ORDER_STATUS = 'A'
      this.data.CURRENT_STAGE = 'SP'
      

      // this.data.ORDER_STATUS = 'A';
      this.data.USER_ID = Number(sessionStorage.getItem('userId'));

      this.data.EXPECTED_PREPARE_PACKAGING_DATETIME = this.datepipe.transform(
        new Date(this.data.EXPECTED_PREPARE_PACKAGING_DATETIME),
        'yyyy-MM-dd HH:mm:ss'
      );
      this.data.EXPECTED_DELIVERY_DATETIME = this.datepipe.transform(
        new Date(this.data.EXPECTED_DELIVERY_DATETIME),
        'yyyy-MM-dd HH:mm:ss'
      );

      this.data.ORDER_CONFIRMED_DATETIME = this.datepipe.transform(
        new Date(),
        'yyyy-MM-dd HH:mm:ss'
      );

      // if (this.data.ID) {
      this.api.updateOrderMaster(this.data).subscribe((successCode) => {
        if (successCode.code == '200') {
          this.message.success(' Information Updated Successfully...', '');
          if (!addNew) this.drawerClose();
          this.isSpinning = false;
        } else {
          this.message.error(' Failed To Update Information...', '');
          this.isSpinning = false;
        }
      });

      // }
    }

   
  }

  dispatched(addNew: boolean, websitebannerPage: NgForm): void {
    this.isSpinning = false;
    this.isOk = true;

    
    if (
     
      (this.data.EXPECTED_DISPATCH_DATETIME == undefined ||
        this.data.EXPECTED_DISPATCH_DATETIME == null)
    ) {
      this.isOk = false;
      this.message.error('Please Select Expected  Dispatching Date. ', '');
    }
    else  if (
      (this.data.EXPECTED_DELIVERY_DATETIME == undefined ||
        this.data.EXPECTED_DELIVERY_DATETIME == null)
    ) {
      this.isOk = false;
      this.message.error('Please Select Expected Delivery Date. ', '');
    }

    

    if (this.isOk) {

      this.data.TO_STAGE = 'Packaging Done'
      this.data.FROM_STAGE = 'Order Confirmed';
      this.data.CURRENT_STAGE = 'D';
      this.data.ORDER_STATUS = 'A'
      this.data.USER_ID = Number(sessionStorage.getItem('userId'));

      this.data.EXPECTED_DISPATCH_DATETIME = this.datepipe.transform(
        new Date(this.data.EXPECTED_DISPATCH_DATETIME),
        'yyyy-MM-dd HH:mm:ss'
      );  
     
      this.data.ORDER_CONFIRMED_DATETIME = this.datepipe.transform(
        new Date(),
        'yyyy-MM-dd HH:mm:ss'
      );
      this.data.EXPECTED_DELIVERY_DATETIME = this.datepipe.transform(
        new Date(this.data.EXPECTED_DELIVERY_DATETIME),
        'yyyy-MM-dd HH:mm:ss'
      );

      // this.data.ACTUAL_DELIVERY_DATETIME = this.datepipe.transform(
      //   new Date(),
      //   'yyyy-MM-dd HH:mm:ss'
      // );

      // console.log('order date time ', this.data.ORDER_CONFIRMED_DATETIME);

      this.isSpinning = true;
      // if (this.data.ID) {
      this.api.updateOrderMaster(this.data).subscribe((successCode) => {
        if (successCode.code == '200') {
          this.message.success(' Information Updated Successfully...', '');
          if (!addNew) this.drawerClose();
          this.isSpinning = false;
        } else {
          this.message.error(' Failed To Update Information...', '');
          this.isSpinning = false;
        }
      });

      // }
    }
  }
}
