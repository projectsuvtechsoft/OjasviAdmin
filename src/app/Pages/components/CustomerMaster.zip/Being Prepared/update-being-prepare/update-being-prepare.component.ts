import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { OrderDetailMaster } from 'src/app/Models/orderdetail';
import { ApiServiceService } from 'src/app/Service/api-service.service';
import * as moment from 'moment';
import { differenceInCalendarDays, setHours } from 'date-fns';

// import { differenceInCalendarDays, setHours } from 'date-fns';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-update-being-prepare',
  templateUrl: './update-being-prepare.component.html',
  styleUrls: ['./update-being-prepare.component.css'],
})
export class UpdateBeingPrepareComponent implements OnInit {
  detailslist: any;

  constructor(
    private message: NzNotificationService,
    private api: ApiServiceService,
    private datepipe: DatePipe
  ) {}
  // this.detailslist = JSON.parse(data['data'][0]['CART_ITEMS'])
  dates: any = [];
  @Input()
  OrdersID:any
  
  @Input()
  confirmdate: any;
  loaddata:any;


  ngOnInit(): void {
    this.loaddata = true
    this.api
      .getAllOrderMaster(0, 0, '', '', " AND CURRENT_STAGE = 'BP' AND ID = "+this.OrdersID)
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.loaddata = false
            this.detailslist = JSON.parse(data['data'][0]['CART_ITEMS']);
          } else {
            this.loaddata = false
            // this.message.error('Something Went Wrong', '');
          }
        },
        (err) => {
          console.log(err);
        }
      );

    this.date = new Date(this.confirmdate);
    // this.date = this.datepipe.transform(new Date (this.confirmdate), 'yyyy-MM-dd');
    console.log('date', this.date);
    console.log(this.confirmdate);
  }

  date: any;

  // disabled = (current: Date): boolean =>
  //   differenceInCalendarDays(current, this.todays) < 0;
  today2 = new Date();
  disabledStartDate2 = (current: Date): boolean =>
    differenceInCalendarDays(current, this.date) < 0;

  disabledEndDate2 = (current: Date): any => {
    let index = this.dates.findIndex(
      (date: any) => date === moment(current).format('YYYY-MM-DD')
    );
    return index === -1 && true;
  };

  todays = new Date();

  loadingRecords1 = false;

  @Input()
  drawerClose!: Function;
  @Input()
  data: OrderDetailMaster = new OrderDetailMaster();
  @Input()
  drawerVisible: boolean = false;
  rejectremark: OrderDetailMaster[] = [];

  isSpinning = false;

  ///
  dateFormat = 'dd-MM-yyyy';

  filteredOptions: any[] = [];

  close(): void {
    this.drawerClose();
  }

  resetDrawer(websitebannerPage: NgForm) {
    this.data = new OrderDetailMaster();
    websitebannerPage.form.markAsPristine();
    websitebannerPage.form.markAsUntouched();
  }

  // update(addNew: boolean, websitebannerPage: NgForm): void {
  //   this.isSpinning = false;
  //   this.isOk = true;

  //   // console.log(this.data.ACTUAL_PREPARE_PACKAGING_DATETIME);
  //   // console.log(this.data.EXPECTED_PREPARE_PACKAGING_DATETIME);

  //   if (
  //     this.data.EXPECTED_BEING_PREPARE == undefined ||
  //     this.data.EXPECTED_BEING_PREPARE == null
  //   ) {
  //     this.isOk = false;
  //     this.message.error('Please Select Expected Preparing Date. ', '');
  //   }

  //   if (this.isOk) {
  //     // this.data.ORDER_STATUS = 'BP'
  //     this.data.USER_ID = Number(sessionStorage.getItem('userId'));

  //     // this.data.ACTUAL_PREPARE_PACKAGING_DATETIME = this.datepipe.transform(new Date(), 'yyyy-MM-dd HH:mm:ss');
  //     this.data.EXPECTED_BEING_PREPARE = this.datepipe.transform(
  //       new Date(this.data.EXPECTED_BEING_PREPARE),
  //       'yyyy-MM-dd HH:mm:ss'
  //     );

  //     // this.isSpinning=false;PREPARE_PACKAGING_ID
  //     // this.data.PREPARE_PACKAGING_ID = Number(sessionStorage.getItem('userId'));

  //     this.isSpinning = true;
  //     if (this.data.ID) {
  //       this.api.updateOrderMaster(this.data).subscribe((successCode) => {
  //         if (successCode.code == '200') {
  //           this.message.success(' Information Updated Successfully...', '');
  //           if (!addNew) this.drawerClose();
  //           this.isSpinning = false;
  //         } else {
  //           this.message.error(' Failed To Update Information...', '');
  //           this.isSpinning = false;
  //         }
  //       });
  //     }
  //   }
  // }

  isOk = true;
  save(addNew: boolean, websitebannerPage: NgForm): void {
    this.isSpinning = false;
    this.isOk = true;

    if (
      this.data.EXPECTED_BEING_PREPARE == undefined ||
      this.data.EXPECTED_BEING_PREPARE == null
    ) {
      this.isOk = false;
      this.message.error('Please Select Expected Preparing Date. ', '');
    }

    if (this.isOk) {
      this.data.TO_STAGE = 'Ordered Prepared';
      this.data.FROM_STAGE = 'Preparing';
      this.data.CURRENT_STAGE = 'OP';
      this.data.ORDER_STATUS = 'BP';

      this.data.USER_ID = Number(sessionStorage.getItem('userId'));


      this.data.EXPECTED_BEING_PREPARE = this.datepipe.transform(
        new Date(this.data.EXPECTED_BEING_PREPARE),
        'yyyy-MM-dd HH:mm:ss'
      );

      this.isSpinning = true;
      if (this.data.ID) {
        this.api.updateOrderMaster(this.data).subscribe((successCode) => {
          if (successCode.code == '200') {
            this.message.success(' Information Updated Successfully...', '');
            if (!addNew) this.drawerClose();
            this.isSpinning = false;
          } else {
            this.message.error(' Failed To Update Information...', '');
            this.isSpinning = false;
          }
        });
      }
    }
  }
}
