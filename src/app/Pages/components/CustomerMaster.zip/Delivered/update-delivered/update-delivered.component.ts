import { DatePipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { OrderDetailMaster } from 'src/app/Models/orderdetail';
import { ApiServiceService } from 'src/app/Service/api-service.service';
import * as moment from 'moment';
import { differenceInCalendarDays, setHours } from 'date-fns';

@Component({
  selector: 'app-update-delivered',
  templateUrl: './update-delivered.component.html',
  styleUrls: ['./update-delivered.component.css'],
})
export class UpdateDeliveredComponent implements OnInit {
  constructor(
    private message: NzNotificationService,
    private api: ApiServiceService,
    private datepipe: DatePipe
  ) {}
  loadingRecords1 = false;

  detailslist: any;
  @Input()
  drawerClose!: Function;
  @Input()
  data: OrderDetailMaster = new OrderDetailMaster();
  @Input()
  drawerVisible: boolean = false;
  rejectremark: OrderDetailMaster[] = [];

  radioval = 'A';
  isOk = true;
  isSpinning = false;
  loaddata:any
  ///
  dateFormat = 'dd-MM-yyyy';
  @Input()
  OrdersID:any

  ngOnInit(): void {
    this.loaddata = true
    this.api
      .getAllOrderMaster(0, 0, '', '', " AND CURRENT_STAGE = 'SP' AND ID = "+this.OrdersID)
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.loaddata = false
            this.detailslist = JSON.parse(data['data'][0]['CART_ITEMS']);
          } else {
            this.loaddata = false
            // this.message.error('Something Went Wrong', '');
          }
        },
        (err) => {
          console.log(err);
        }
      );

    console.log('dd', this.confirmdate);
    this.date2 = new Date(this.confirmdate);
    console.log('date', this.date);
  }
  @Input()
  confirmdate: any;

  todays = new Date();

  dates: any = [];
  date: any;
  date2: any;

  today2 = new Date();
  disabledStartDate2 = (current: Date): boolean =>
    differenceInCalendarDays(current, this.date2) < 0;

  disabledEndDate2 = (current: Date): any => {
    let index = this.dates.findIndex(
      (date: any) => date === moment(current).format('YYYY-MM-DD')
    );
    return index === -1 && true;
  };

  filteredOptions: any[] = [];

  close(): void {
    this.drawerClose();
  }
  resetDrawer(websitebannerPage: NgForm) {
    this.data = new OrderDetailMaster();
    websitebannerPage.form.markAsPristine();
    websitebannerPage.form.markAsUntouched();
  }

  // update(addNew: boolean, websitebannerPage: NgForm): void {
  //   //PREPARE_DISPATCH_ID
  //   this.isSpinning = false;
  //   this.isOk = true;

  //   if(this.data.EXPECTED_PREPARE_PACKAGING_DATETIME== undefined || this.data.EXPECTED_PREPARE_PACKAGING_DATETIME==null){
  //     this.isOk =false
  //     this.message.error('Please Select Expected Packaging Date. ','')
  //   }

  //   if (this.isOk) {
  //     // this.isSpinning=false;
  //     // this.data.DISPATCH_ID = Number(sessionStorage.getItem("userId"))

  //     // this.data.ORDER_STATUS = 'D'
  //     // this.data.ACTUAL_DISPATCH_DATETIME = this.datepipe.transform(new Date(), 'yyyy-MM-dd HH:mm:ss');
  //     this.data.EXPECTED_PREPARE_PACKAGING_DATETIME = this.datepipe.transform(new Date( this.data.EXPECTED_PREPARE_PACKAGING_DATETIME), 'yyyy-MM-dd HH:mm:ss');

  //     this.isSpinning = true;
  //     if (this.data.ID) {
  //       this.api.updateOrderMaster(this.data).subscribe((successCode) => {
  //         if (successCode.code == '200') {
  //           this.message.success(' Information Updated Successfully...', '');
  //           if (!addNew) this.drawerClose();
  //           this.isSpinning = false;
  //         } else {
  //           this.message.error(' Failed To Update Information...', '');
  //           this.isSpinning = false;
  //         }
  //       });
  //     }

  //   }

  //   // else
  //   // {
  //   //   this.message.error("Please Fill All Required Fields...","");
  //   //   this.isSpinning = false;

  //   // }
  // }

  save(addNew: boolean, websitebannerPage: NgForm): void {
    //PREPARE_DISPATCH_ID
    this.isSpinning = false;
    this.isOk = true;

    if (
      this.data.EXPECTED_PREPARE_PACKAGING_DATETIME == undefined ||
      this.data.EXPECTED_PREPARE_PACKAGING_DATETIME == null
    ) {
      this.isOk = false;
      this.message.error('Please Select Expected Package Preparing Date. ', '');
    }

    if (this.isOk) {
      // this.isSpinning=false;

      this.data.TO_STAGE = 'Packaging Done';
      this.data.FROM_STAGE = 'Start Packaging';
      this.data.CURRENT_STAGE = 'PD';
      this.data.ORDER_STATUS = 'SP';
      this.data.USER_ID = Number(sessionStorage.getItem('userId'));

      this.data.EXPECTED_PREPARE_PACKAGING_DATETIME = this.datepipe.transform(
        new Date(this.data.EXPECTED_PREPARE_PACKAGING_DATETIME),
        'yyyy-MM-dd HH:mm:ss'
      );

      this.isSpinning = true;
      if (this.data.ID) {
        this.api.updateOrderMaster(this.data).subscribe((successCode) => {
          if (successCode.code == '200') {
            this.message.success(' Information Updated Successfully...', '');
            if (!addNew) this.drawerClose();
            this.isSpinning = false;
          } else {
            this.message.error(' Failed To Update Information...', '');
            this.isSpinning = false;
          }
        });
      }
    }
  }
}
