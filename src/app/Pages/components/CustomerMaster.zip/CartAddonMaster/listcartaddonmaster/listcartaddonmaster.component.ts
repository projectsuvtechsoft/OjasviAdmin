import { Component, OnInit } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { CartAddonMaster } from 'src/app/Models/CartAddonMaster';
import { CategoryMaster } from 'src/app/Models/categorymaster';
import { ApiServiceService } from 'src/app/Service/api-service.service';

@Component({
  selector: 'app-listcartaddonmaster',
  templateUrl: './listcartaddonmaster.component.html',
  styleUrls: ['./listcartaddonmaster.component.css']
})
export class ListcartaddonmasterComponent implements OnInit {

  constructor(private api: ApiServiceService , private notify:NzNotificationService) { }

  ngOnInit(): void {
  }

  formTitle = " Cart Addon Master List ";
  loadingRecords = false;
  totalRecords = 1;
  pageIndex = 1;
  pageSize = 10;
  sortValue: string = "desc";
  sortKey: string = "id";
  searchText: string = "";
  filterQuery: string = "";
  isFilterApplied: string = "default";
  columns: string[][] = 

  [ ["TITLE"," title "], 
  ["AMOUNT","amount"],
  ["CART_TOTAL_PERCENTAGE","cart percentage"]
]
           
 drawerData: CartAddonMaster = new CartAddonMaster();

  dataList:any[] = [];


    keyup(event:any) {
    this.search();
  }

  drawerVisible!: boolean;
  drawerTitle!: string;
 
  drawerClose(): void {
    this.search();
    this.drawerVisible = false;
  }


  get closeCallback() {
    return this.drawerClose.bind(this);
  }
  search(reset: boolean = false) {
    if (reset) {
      this.pageIndex = 1;
      this.sortKey = "id";
      this.sortValue = "desc"
    }
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith("a") ? "asc" : "desc";
    } catch (error) {
      sort = "";
    }
    var likeQuery = "";
    console.log("search text:" + this.searchText);
    if (this.searchText != "") {
      likeQuery = " AND";
      this.columns.forEach(column => {
        likeQuery += " " + column[0] + " like '%" + this.searchText + "%' OR";
      });
      likeQuery = likeQuery.substring(0, likeQuery.length - 2)
      console.log("likeQuery" + likeQuery);
    }

    this.api.getAllCartAddOnMaster(this.pageIndex, this.pageSize, this.sortKey, sort, likeQuery).subscribe(data => {
      console.log('show',data)

      if(data['code']==200){
      
      this.loadingRecords = false;
      this.totalRecords = data['count'];
      this.dataList = data['data'];
     
      }
      else{
        this.loadingRecords=false;
        this.notify.error('Something Went Wrong','')
      }


    }, err => {
      console.log(err);
    });


  
  }

  edit(data: CartAddonMaster): void {
    this.drawerTitle = " Update Addon Master Information";
    this.drawerData = Object.assign({}, data);
    this.drawerVisible = true;
  }

  add(): void {
    this.drawerTitle = " Add New Addon Master Information "; 
    this.drawerData = new CartAddonMaster();
    // this.api.getAllCategoryMaster(1,1,'SEQUENCE_NO','desc','').subscribe (data =>{
    //   if (data['count']==0){
    //     this.drawerData.SEQUENCE_NO=1;
    //   }else
    //   {
    //     this.drawerData.SEQUENCE_NO=data['data'][0]['SEQUENCE_NO']+1;
    //   }
    // },err=>{
    //   console.log(err);
    // })
    this.drawerVisible = true;
  }

  sort(params: NzTableQueryParams): void {
    const { pageSize, pageIndex, sort} = params;
    const currentSort = sort.find(item => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id'; 
    // const sortOrder = (currentSort && currentSort.value) || 'asc';
    const sortOrder = (currentSort && currentSort.value) || 'desc';

    console.log(currentSort)

    console.log("sortOrder :"+sortOrder)
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;

    if(this.pageSize != pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }    
    
    if( this.sortKey != sortField) {
      this.pageIndex = 1;
      this.pageSize =pageSize;
    }

    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.search();
  }

}
