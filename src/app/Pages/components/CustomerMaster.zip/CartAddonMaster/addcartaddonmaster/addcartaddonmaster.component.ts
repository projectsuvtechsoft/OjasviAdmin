import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { CartAddonMaster } from 'src/app/Models/CartAddonMaster';
import { ApiServiceService } from 'src/app/Service/api-service.service';

@Component({
  selector: 'app-addcartaddonmaster',
  templateUrl: './addcartaddonmaster.component.html',
  styleUrls: ['./addcartaddonmaster.component.css']
})
export class AddcartaddonmasterComponent implements OnInit {

  constructor(private message: NzNotificationService , private api:ApiServiceService) { }

  ngOnInit(): void {
  }

  @Input()
  drawerClose!: Function;
  @Input()
  data: CartAddonMaster = new CartAddonMaster();
  @Input()
  drawerVisible: boolean = false;

  isSpinning = false;
  alphaOnly(event:any) {
    event = (event) ? event : window.event;
    var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 32 && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
      return false;
    }
    return true;
  }

  omit(event: any) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  close(): void {
    this.drawerClose();
  }

  //number and dot
  onlynumdot(event: any) {
    event = event ? event : window.event;
    var charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 46 || charCode > 57)) {
      return false;
    }
    return true;
  }

  isOk=true;

  resetDrawer(websitebannerPage: NgForm) {
    this.data=new CartAddonMaster();
    websitebannerPage.form.markAsPristine();
    websitebannerPage.form.markAsUntouched();
  }


  save(addNew: boolean,websitebannerPage: NgForm): void {
    this.isSpinning = false;
    this.isOk=true;
 
    if (
      this.data.TITLE.trim()==''  
       ) {
      this.isOk = false;
      this.message.error(' Please Fill All Required Fields', '');


    } 


    else if (this.data.TITLE.trim() == '' || this.data.TITLE == undefined) {
      this.isOk = false;
      this.message.error(' Please Enter Title', '');

    } 

    else
    if(this.data.IS_AMOUNT_BASED == true && ( this.data.AMOUNT == undefined || this.data.AMOUNT <=0)){

     this.isOk =false
     this.message.error('Please Enter Amount','')
  
    } 


    else
    if(this.data.IS_AMOUNT_BASED == true && ( this.data.CART_TOTAL_PERCENTAGE == undefined || this.data.CART_TOTAL_PERCENTAGE <=0)){

     this.isOk =false
     this.message.error('Please Enter Cart Total Percentage','')
  
    }

    if(this.isOk)
    {
      this.isSpinning=true;
      // this.isSpinning=false; 
      if(this.data.IS_AMOUNT_BASED == false && ( this.data.AMOUNT == undefined || this.data.AMOUNT >0)){
        this.data.AMOUNT = 0
      }else{
        this.data.AMOUNT = this.data.AMOUNT
      }

      if(this.data.IS_AMOUNT_BASED == false && ( this.data.CART_TOTAL_PERCENTAGE == undefined || this.data.CART_TOTAL_PERCENTAGE >0)){
        this.data.CART_TOTAL_PERCENTAGE = 0
      }else{
        this.data.CART_TOTAL_PERCENTAGE = this.data.CART_TOTAL_PERCENTAGE
      }

     if(this.data.ID)
    {
      this.api.updateCartAddOnMaster(this.data)
      .subscribe(successCode => {
        if(successCode.code=="200")
        {
          this.message.success(" Information Updated Successfully...", "");
            if(!addNew)
            this.drawerClose();
            this.isSpinning = false;
        }   
        else
        {
          this.message.error(" Failed To Update Information...", "");
          this.isSpinning = false;
        }
      });
    }
    else{
     
        this.api.createCartAddOnMaster(this.data)
        // this.type=.TYPE_ID
        .subscribe(successCode => {
          if(successCode.code=="200")
          {
            this.message.success(" Information Save Successfully...", "");
             if(!addNew)
             this.drawerClose();
              else
              {
                this.data=new CartAddonMaster();
                this.resetDrawer(websitebannerPage);                
                // this.api.getAllUnitMaster(1,1,'','desc','').subscribe (data =>{
                //   if (data['count']==0){
                //     this.data.SEQUENCE_NO=1;
                //   }else
                //   {
                //     this.data.SEQUENCE_NO=data['data'][0]['SEQUENCE_NO']+1;
                //   }
                // },err=>{
                //   console.log(err);
                // })
              }
              this.isSpinning = false;
            }
             else
             {
              this.message.error(" Failed To Save Information...", "");
              this.isSpinning = false;
             }
            });
          }
    }
  
  // else
  // {
  //   this.message.error("Please Fill All Required Fields...","");
  //   this.isSpinning = false;
  
  // }
}
}
