import { Component, Input, OnInit } from '@angular/core';
import { cartaddondetails } from 'src/app/Models/cartaddondetails';

@Component({
  selector: 'app-addcartaddondetails',
  templateUrl: './addcartaddondetails.component.html',
  styleUrls: ['./addcartaddondetails.component.css']
})
export class AddcartaddondetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  @Input()
  drawerClose!: Function;
  @Input()
  data: cartaddondetails = new cartaddondetails();
  @Input()
  drawerVisible: boolean = false;
}
